<?php
/**
 # ------------------------------------------------------------------------
 # JPRO CUSTOM HTML
 # ------------------------------------------------------------------------
 # @package      mod_jpro_custom_html
 # @version      1.0
 # @created      August 2015
 # @author       Joomla Pro
 # @email        admin@joomla-pro.org
 # @websites     http://joomla-pro.org
 # @copyright    Copyright (C) 2015 Joomla Pro. All rights reserved.
 # @license      GNU General Public License version 2, or later
 # ------------------------------------------------------------------------
**/

if (!defined( '_JEXEC' )) die;

$html = $params->get('html');
$mode = $params->get('mode',1);
$plugins = $params->get('plugins',0);

if ($plugins) {
	JPluginHelper::importPlugin('content');
	$contentconfig = JComponentHelper::getParams('com_content');
	$dispatcher = JDispatcher::getInstance();
	$item = new stdClass();
	$item->text = $html;
	$results = $dispatcher->trigger('onContentPrepare', array ('com_content.article', &$item, &$contentconfig, 0 ));
	$html = $item->text;
}

switch ($mode) {
	case 2: // CSS
		$doc = JFactory::getDocument();
		$doc->addStyleDeclaration($html,'text/css');
	break;
	case 3: // JavaScript
		$doc = JFactory::getDocument();
		$doc->addScriptDeclaration($html,'text/javascript');
		break;
	default: // HTML
		echo $html;
}
